# Online shop incident log test data

This folder contains ten synthetic, UTF-8 JSON incident timelines designed for upload to the DevOps Incident Analysis Suite.

Each file is a top-level array of six chronological event objects and includes warning signals, measurable customer impact, response actions, and recovery evidence. All identifiers, addresses, metrics, and business impacts are fictional.

| File | Intended primary classification |
|---|---|
| `01-postgres-connection-pool-exhaustion.json` | `database` |
| `02-checkout-dns-resolution-failure.json` | `networking` |
| `03-product-image-disk-capacity.json` | `capacity` |
| `04-cart-deployment-regression.json` | `deployment_regression` |
| `05-payment-provider-unavailable.json` | `dependency_failure` |
| `06-search-latency-degradation.json` | `performance` |
| `07-customer-login-token-expiry.json` | `authentication` |
| `08-fulfilment-worker-crashloop.json` | `infrastructure` |
| `09-account-brute-force-attack.json` | `possible_security_event` |
| `10-inventory-reservation-application-error.json` | `application_error` |
